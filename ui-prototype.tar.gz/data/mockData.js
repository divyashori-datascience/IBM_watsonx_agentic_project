
'use strict';

const PERSONAS = {
  student: { name: 'Felix', label: 'Campus Felix', segment: 'Student', age: 22, income: 'CHF 800–2,000/mo', feeCeiling: 'CHF 5', pct: 8, color: '#6366f1', avatar: 'F' },
  professional: { name: 'Lukas', label: 'Mobile-First Lukas', segment: 'Professional', age: 32, income: 'CHF 8,500–11,200/mo', feeCeiling: 'CHF 25–30', pct: 12, color: '#0ea5e9', avatar: 'L' },
  mittelstand: { name: 'Anna', label: 'Average-Earner Anna', segment: 'Mittelstand', age: 36, income: 'CHF 5,600/mo', feeCeiling: 'CHF 12', pct: 28, color: '#10b981', avatar: 'A' },
  family: { name: 'Sandra', label: 'Value-Smart Sandra', segment: 'Family', age: 44, income: 'CHF 7,500–9,800/mo', feeCeiling: 'CHF 10', pct: 22, color: '#f59e0b', avatar: 'S' },
  retired: { name: 'Peter', label: 'Trust-First Peter', segment: 'Retired', age: 65, income: 'CHF 1,682/mo', feeCeiling: 'CHF 5', pct: 18, color: '#ef4444', avatar: 'P' },
};

const QUESTION_BANKS = {
  'Visa card adoption and payment behavior in Switzerland': [
    { id: 'Q1', category: 'price_sensitivity', text: 'Would you consider paying a monthly fee of CHF 8 for a Visa card that offers 1% cashback on all grocery purchases at Migros and Coop?' },
    { id: 'Q2', category: 'feature_preference', text: 'Which of the following card features would be most valuable to you: grocery cashback, travel insurance, no foreign transaction fees, or purchase protection on larger items?' },
    { id: 'Q3', category: 'behavior_switching', text: 'What would it take for you to switch from Twint to using a Visa card as your primary payment method for everyday purchases in Switzerland?' },
    { id: 'Q4', category: 'trade_off', text: 'Would a CHF 50 welcome bonus be enough to make you try a new Visa card with a CHF 6/month fee for the first year?' },
    { id: 'Q5', category: 'willingness_to_pay', text: 'What is the maximum monthly fee you would realistically pay for a Visa card, assuming the benefits are well-matched to your lifestyle?' },
  ],
  'mobile payment and Twint competition': [
    { id: 'Q1', category: 'behavior_switching', text: 'Twint is free and works everywhere in Switzerland. What specific feature or benefit would convince you to add a Visa card to your payment stack?' },
    { id: 'Q2', category: 'feature_preference', text: 'When you travel outside Switzerland, what payment method do you currently use, and what problems — if any — do you experience?' },
    { id: 'Q3', category: 'price_sensitivity', text: 'If a Visa card had zero foreign transaction fees and saved you money on international travel, would a CHF 10/month fee still feel too expensive?' },
    { id: 'Q4', category: 'trade_off', text: 'Would you prefer a card with 2% cashback only at supermarkets, or 0.5% cashback on all purchases including dining, transport, and online shopping?' },
    { id: 'Q5', category: 'willingness_to_pay', text: 'If your friends or colleagues all switched to a new Visa card product, how likely would you be to follow — and would that change your fee tolerance?' },
  ],
  'cashback and rewards programs in Switzerland': [
    { id: 'Q1', category: 'feature_preference', text: 'How important is it to you that cashback rewards come back as real cash, rather than as vouchers, points, or store credit at specific retailers?' },
    { id: 'Q2', category: 'price_sensitivity', text: 'If a card costs CHF 6/month but returns CHF 8/month in grocery cashback based on your typical spending, would that math convince you to sign up?' },
    { id: 'Q3', category: 'behavior_switching', text: 'You currently get no cashback from your main payment method. How much monthly cashback would you need to see before switching to a Visa card with a fee?' },
    { id: 'Q4', category: 'trade_off', text: 'Would you prefer a free card with no cashback, a CHF 5/month card with 0.5% cashback on groceries, or a CHF 12/month card with 1.5% cashback on all spending?' },
    { id: 'Q5', category: 'willingness_to_pay', text: 'If you knew a Visa card would save your household CHF 15–20 per month on grocery spending, what monthly fee would you consider reasonable?' },
  ],
};

const PERSONA_RESPONSES = {
  student: {
    price_sensitivity: [
      "CHF 8 a month? That's CHF 96 a year. Honestly, no. My debit card is free and Twint is free — I don't see why I'd pay for something I already have for nothing. Maybe if the cashback genuinely covered the fee and then some, but I'd have to see real numbers.",
      "I'd need to really think about that. CHF 8 is a lot when you're a student. Right now every franc counts. Unless the cashback was actually CHF 10+ a month back, I'd probably just stick with what I have.",
      "No. I set a hard limit of CHF 5/month for anything subscription-like. CHF 8 already crosses that. There are free cards out there — Neon doesn't charge me anything.",
    ],
    feature_preference: [
      "Honestly, none of those really click for me. No foreign fees could be useful if I travelled more but I barely leave Switzerland. Cashback on groceries is probably the most useful, but only if it's actually meaningful — not some tiny fraction. Mostly I just want zero fees.",
      "Cashback on groceries, for sure. That's where most of my money goes — Aldi, Lidl, sometimes Coop. If I'm spending CHF 300 a month on food, even 1% back is something. Travel insurance is useless to me right now.",
      "I'd say grocery cashback is the only one that makes sense for my lifestyle. Everything else is for people with more money than me.",
    ],
    behavior_switching: [
      "Twint works everywhere here and it's free. For me to switch, the card would have to be completely free AND offer something Twint doesn't. Like cashback — Twint doesn't give me anything back. But the moment there's a monthly fee, forget it.",
      "It would have to be free and really fast. Twint is instant — splitting a dinner takes two seconds. A card would need to actually beat that somehow. I'm not switching just for a shiny design.",
      "Peer pressure honestly. If all my WG flatmates switched to something, I'd probably follow just to keep splitting bills simple. But it still has to be free or basically free.",
    ],
    trade_off: [
      "CHF 50 welcome bonus sounds tempting but then I'd owe CHF 72 over the year. That's actually a loss of CHF 22 if I don't use it enough. I'd do the math first and probably pass.",
      "Maybe. If I could cancel after one month without penalty I might try it for the bonus. But if there's a lock-in, no. I hate being trapped in subscriptions.",
      "Honestly I'd feel tricked by that. Sign-up bonus to get you hooked and then you forget to cancel. I've read about that pattern. I'd be skeptical.",
    ],
    willingness_to_pay: [
      "CHF 5. That's genuinely my absolute maximum. And even then I'd want a really clear benefit that I could verify within the first week. Anything above CHF 5 and there are free alternatives I'd pick first.",
      "Zero, ideally. If there's a fee at all, CHF 3–5 is the ceiling. I'm a student. CHF 10/month is CHF 120 a year — that's a month of groceries.",
      "CHF 5, and only if I could cancel anytime without hassle. I don't want to be stuck paying for something that stops being useful.",
    ],
  },
  professional: {
    price_sensitivity: [
      "Yes, easily. CHF 8 a month is nothing if 1% cashback applies to serious grocery spending. My partner and I spend around CHF 800–1,000/month at Migros and Coop — 1% back is CHF 8–10. The fee basically pays for itself from day one. The real question is whether the cashback rate is competitive.",
      "Absolutely. The fee is trivial at my income level. I care more about whether the cashback rate is actually 1% or whether there are thresholds and caps that reduce it in practice. Show me the actual numbers.",
      "CHF 8/month is irrelevant to me — I spend that on a coffee. What matters is the total value of the card's benefit stack. If it includes travel insurance and no foreign fees alongside the cashback, it's clearly worth more than the fee.",
    ],
    feature_preference: [
      "No foreign transaction fees — without question. I travel four to six times a year and the 1.5% on every transaction abroad adds up to hundreds of francs. Travel insurance is second. Cashback on groceries is nice but not my primary driver.",
      "Travel insurance and no foreign fees — those two together are what I need. I book hotels and flights internationally all the time. Cashback is useful but I'd rather have the protection and zero foreign fees.",
      "For me it's: (1) no foreign fees, (2) travel insurance, (3) Apple Pay compatibility — non-negotiable. I use Apple Pay for basically everything. Cashback is table stakes now, not a differentiator.",
    ],
    behavior_switching: [
      "Twint is for splitting bills in Switzerland, not for serious spending. I already use a credit card for travel and larger purchases. If Visa offered a clearly better cashback rate than my current card plus travel insurance, I'd switch within a week. I have a low friction threshold for clearly better products.",
      "I'd switch for a better cashback rate on restaurants and travel. My current card gives 0.5% — if Visa offered 1.5% on those categories with comparable travel insurance, that's a meaningful improvement. I do the math instinctively.",
      "Give me a card that works seamlessly with Apple Pay, has zero foreign fees, and returns meaningful cashback — I'd have it set up before the end of the week. The barrier is low when the product is clearly superior.",
    ],
    trade_off: [
      "Definitely yes. I'd probably sign up for the bonus alone and then keep it if the overall value stack holds up. CHF 50 upfront against CHF 72/year is nearly break-even in year one — and if the card's benefits exceed CHF 6/month in ongoing value, it's a clear win.",
      "Yes, with one condition — I need to be convinced the card earns its fee beyond year one. The welcome bonus sweetens the deal but isn't the deciding factor. I'd evaluate the ongoing value.",
      "Yes. CHF 50 is meaningful and the CHF 6/month fee is low. If the card's ongoing benefits are solid — which I'd verify before signing up — this is an easy yes.",
    ],
    willingness_to_pay: [
      "CHF 25–30/month for a genuinely premium card with strong travel insurance, airport lounge access, and no foreign fees. For a mid-range card with grocery cashback only, CHF 10–15 is reasonable. The fee ceiling scales with the value stack.",
      "For a card that covers my travel and daily spending well, CHF 20/month is easy to justify. I spend CHF 3,000+ on my card monthly — even 0.8% back covers a CHF 24 fee. The math is straightforward.",
      "Up to CHF 25 for the right product. I would need: no foreign fees, real travel insurance, Apple Pay, and cashback above 1% on my main spending categories. That combination is clearly worth CHF 25/month at my spending volume.",
    ],
  },
  mittelstand: {
    price_sensitivity: [
      "CHF 8 a month is CHF 96 a year — I always think about it annually. If I spend around CHF 500 on groceries, 1% cashback is CHF 5/month. That doesn't quite cover the fee. If the cashback applied to dining out too, and I verified the numbers actually showed up, I might consider it — but I'd want a free trial first.",
      "It's borderline for me. CHF 8 is not nothing. I'd need to sit down and calculate whether the cashback actually covers the fee based on my real spending. And I'd want to read reviews from other Swiss users, not just marketing material.",
      "I'm open to it but skeptical by default. CHF 96/year is real money. I'd want a one-month trial where I could see exactly how much cashback I'd earned before committing. Show me the proof, not the promise.",
    ],
    feature_preference: [
      "Grocery cashback is most useful for my life — I spend CHF 450–600 a month at Migros and Lidl. Purchase protection on larger buys is second. Travel insurance and no foreign fees don't matter much since I mostly travel within Switzerland.",
      "Cashback on groceries and dining, because that's where my money goes. I'd also want Twint compatibility — I use it for splitting bills with friends constantly. Travel perks are irrelevant to my life right now.",
      "Simple, tangible cashback on supermarket spending. Not points, not vouchers — actual money back. I want to see a real CHF amount on my monthly statement. Everything else is secondary.",
    ],
    behavior_switching: [
      "A free trial and evidence it saves me money on my actual spending. Maybe a recommendation from a friend who's been using it for a few months and can show me their cashback total. I don't switch for marketing promises — I switch for demonstrated value.",
      "If my current bank raised fees, I'd be more motivated to look around. Or if a friend showed me clear proof that a Visa card was saving them CHF 15+/month on groceries. Word of mouth from someone I trust matters more than any advertisement.",
      "Clear cashback on my main categories, a free month to test it, and the ability to cancel easily. I research everything before committing — I'd read Swiss consumer forums, check comparison sites, then decide.",
    ],
    trade_off: [
      "CHF 50 upfront vs CHF 72/year. The first year is nearly break-even. But I'd think: what happens in year two? If the card genuinely returns CHF 10+ per month in cashback by then, it makes sense long-term. I'd try it — carefully.",
      "Maybe, with a cancellation option after month one. I'd take the bonus and use the trial period to verify the cashback actually shows up as promised. If it does, I'd keep it. If the numbers disappoint, I'd cancel.",
      "I'd calculate it. CHF 50 bonus minus CHF 72 annual fee is a CHF 22 net cost in year one if there's zero cashback. But with 1% grocery cashback on CHF 500/month, that's CHF 60/year back — so I'd come out about CHF 38 ahead. That actually works.",
    ],
    willingness_to_pay: [
      "CHF 8–10 per month, but only if I can verify the cashback covers it within the first month or two. CHF 12 is my absolute ceiling and that would require a genuinely strong cashback rate on my actual spending. I'm not paying for abstract future value.",
      "Realistically CHF 6–8 for something useful. CHF 12 is possible only if there's a free trial and the cashback clearly exceeds the fee in practice. I'd test it with my actual spending before committing.",
      "CHF 8 is my comfort zone. I could stretch to CHF 10 for the right product — simple, honest, with cashback on groceries and dining. Above CHF 12, I'd need extraordinary justification.",
    ],
  },
  family: {
    price_sensitivity: [
      "We spend around CHF 1,000–1,200 a month on groceries for a family of four. If 1% cashback at Migros and Coop returns CHF 10–12/month, a CHF 8 fee basically pays for itself. I'd still want to run it by my partner and see the fine print, but the math is interesting.",
      "It depends on whether 'grocery purchases' includes everything we actually buy — Migros, Coop, but also the weekly Aldi run. If it's only certain stores, the cashback might be less than it looks. I'd need to check carefully before committing.",
      "Possibly. CHF 8 is manageable if the benefit is genuinely family-relevant. But my partner and I would discuss it first — we make financial decisions together. And I'd want to know: can we cancel easily if it doesn't deliver?",
    ],
    feature_preference: [
      "Purchase protection on larger family purchases, and cashback on groceries. Those two directly help our household budget. We spend a lot on appliances, children's equipment, school gear — knowing there's purchase protection reduces risk. Travel insurance is useful for family holidays once a year.",
      "Grocery cashback first — we're at Migros or Coop two or three times a week. Purchase protection second, for the bigger family purchases. We don't travel internationally very often so no foreign fees is lower priority.",
      "Honestly, anything that reduces our grocery bill. Every month we track our spending and food is always the biggest variable cost. Cashback there would be immediately visible. Purchase protection is a bonus I'd genuinely use.",
    ],
    behavior_switching: [
      "We'd need to see a clear family benefit — not just abstract cashback but something that visibly reduces our household costs. And both my partner and I would need to agree. There's also friction: we have direct debits and bill payments linked to our current setup. The benefit has to outweigh the hassle of switching.",
      "If our grocery cashback genuinely saved us CHF 15–20 a month and the card was simple to use, that might tip us. But I'd still want to stay with our existing bank — just add the card as a complement, not replace everything.",
      "A trusted friend or our bank advisor would be the most convincing. Not an ad. If someone we trust said 'this saved our family CHF X last year', that would get us seriously looking. We don't act on marketing alone.",
    ],
    trade_off: [
      "A CHF 50 bonus helps but I'd think beyond year one. Is the card worth keeping after the bonus? I'd evaluate the ongoing cashback against the CHF 6 monthly fee. If groceries return CHF 8–10/month, yes, it's worth it long-term. My partner and I would calculate it together.",
      "Possibly, if the cancellation is genuinely easy and there's no penalty. We've been caught by subscriptions before — the welcome bonus looks good but then you forget to cancel. I'd put a calendar reminder.",
      "CHF 50 is a nice start. Combined with grocery cashback that covers the monthly fee, it could work. But my partner would need to agree, and we'd want to see exactly which stores qualify for the cashback.",
    ],
    willingness_to_pay: [
      "CHF 5–8 per month, only if the benefit is family-relevant. CHF 10 is possible if the cashback covers it — our grocery spending makes that feasible. Above CHF 10, I'd need to see extraordinary value. We manage a household budget carefully.",
      "For our family, CHF 8 makes sense if cashback on supermarkets genuinely returns more than the fee. CHF 10 is the ceiling. We're not going to pay CHF 15 a month for a card that gives us lounge access we'd never use.",
      "CHF 5 feels comfortable. I could go to CHF 8 if the cashback on groceries was clearly positive over the month. My partner and I would set a budget rule: if the cashback doesn't cover the fee any given month, we cancel.",
    ],
  },
  retired: {
    price_sensitivity: [
      "No, I wouldn't. CHF 8 a month is CHF 96 a year and my pension is fixed — it doesn't grow. My PostFinance debit card does everything I need for free. I don't see why I'd add a monthly cost for something I'm managing fine without.",
      "No. I've never needed a credit card and I don't need one now. Every franc I spend on fees is a franc that doesn't go toward health insurance or groceries. CHF 8 is not a small amount on a pension.",
      "I'd have to think about it for a long time, and I'm fairly sure the answer would be no. I don't understand why I'd pay for something when my card already works. What exactly does this cashback mean in practice — where does the money actually go?",
    ],
    feature_preference: [
      "Security — that's the first and most important thing for me. If something goes wrong, I want to call someone who speaks German and get it sorted. Simplicity comes second. I don't need travel insurance or cashback schemes. I just need a card that works reliably and keeps my money safe.",
      "I'd want to know it's backed by a bank I can trust. Security, reliability, and being able to call someone on the phone. Everything else — cashback, travel — I don't really need. I'm 65. I'm not travelling to international airports.",
      "Simple and secure. I've used PostFinance for 40 years and nothing has gone wrong. If a new product can't match that reliability and give me a person to call if there's a problem, I'm not interested.",
    ],
    behavior_switching: [
      "Very little would make me switch, honestly. My routine works. I go to the ATM on Monday morning and pay cash where I can. My PostFinance card handles the rest. If PostFinance themselves recommended something and explained it clearly, I might listen. Otherwise, no.",
      "I wouldn't switch unless my bank told me I had to. Even then, my wife and I would want to sit down with someone at the branch and understand exactly what we're doing. This is our money — we don't move it around lightly.",
      "Nothing in the near term. My setup has worked for decades. The only thing that might push me is if ATMs became even harder to find or PostFinance changed something fundamental. Even then, I'd go to the branch and ask what they recommend.",
    ],
    trade_off: [
      "CHF 50 welcome bonus doesn't interest me. I'd see it as a trap — they give you CHF 50 and then charge you CHF 120/year. In two years you're behind. I've seen these offers before. The math isn't as generous as it looks.",
      "No. I don't want a credit product. I pay for things when I have the money. That's how I've always done it and it's kept me out of financial trouble. A welcome bonus doesn't change that.",
      "I'd be suspicious of a welcome bonus. Why are they giving money away? There must be something I'm missing. My wife would say the same thing. We'd probably say no.",
    ],
    willingness_to_pay: [
      "CHF 0, ideally. If something costs money every month, it had better be absolutely essential. My pension barely covers my costs as it is. CHF 5 is the very maximum I'd even consider, and only for something I genuinely understood and trusted completely.",
      "Nothing, really. I have no need for a fee-paying card. If PostFinance offered something for free that was simple and added a bit of security, I might look. But a monthly fee? No.",
      "CHF 5 at most, and even that feels unnecessary. I'm not against paying for good service — I've paid PostFinance for years — but I already pay them and it already works. Adding another fee for another card doesn't make sense to me.",
    ],
  },
};

const TOPIC_QUESTIONS = {
  default: QUESTION_BANKS['Visa card adoption and payment behavior in Switzerland'],
};

function getQuestionsForTopic(topic) {
  const t = (topic || '').toLowerCase();
  if (t.includes('twint') || t.includes('mobile')) return QUESTION_BANKS['mobile payment and Twint competition'];
  if (t.includes('cashback') || t.includes('reward')) return QUESTION_BANKS['cashback and rewards programs in Switzerland'];
  return QUESTION_BANKS['Visa card adoption and payment behavior in Switzerland'];
}

function getPersonaResponse(personaKey, category, questionIndex) {
  const pool = PERSONA_RESPONSES[personaKey]?.[category] || PERSONA_RESPONSES[personaKey]?.price_sensitivity;
  if (!pool) return '[Response not available]';
  return pool[questionIndex % pool.length];
}

function generateAnalystInsight(question, questionIndex, selectedPersonas) {
  const verdicts = {
    student:      { verdict: 'NO',    key_reasoning: 'Fee ceiling of CHF 5 is firmly held; any cost above this triggers rejection regardless of benefits.', fee_ceiling: 'CHF 5' },
    professional: { verdict: 'YES',   key_reasoning: 'Value-driven evaluation confirms benefits clearly exceed cost at high spending volume.', fee_ceiling: 'CHF 25–30' },
    mittelstand:  { verdict: 'MAYBE', key_reasoning: 'Research-oriented — needs free trial to verify cashback covers the fee before committing.', fee_ceiling: 'CHF 12' },
    family:       { verdict: 'MAYBE', key_reasoning: 'Joint household decision required; benefit must be family-relevant and clearly cashback-positive.', fee_ceiling: 'CHF 10' },
    retired:      { verdict: 'NO',    key_reasoning: 'Fixed pension income with principled objection to any new monthly cost above CHF 5.', fee_ceiling: 'CHF 5' },
  };

  const seg_responses = {};
  selectedPersonas.forEach(p => { seg_responses[PERSONAS[p].name] = verdicts[p]; });

  const yesCount   = selectedPersonas.filter(p => verdicts[p].verdict === 'YES').length;
  const maybeCount = selectedPersonas.filter(p => verdicts[p].verdict === 'MAYBE').length;
  const noCount    = selectedPersonas.filter(p => verdicts[p].verdict === 'NO').length;

  const confidence = selectedPersonas.length >= 4 ? 'HIGH' : 'MEDIUM';

  return {
    insight_id:         `insight_q${questionIndex + 1}`,
    question_id:        question.id,
    question_text:      question.text,
    question_category:  question.category,
    personas_analysed:  selectedPersonas.length,
    segment_responses:  seg_responses,
    cross_segment_insight: `Significant divergence exists across segments driven by income and life stage. The professional segment (12%) adopts immediately when value is demonstrable. Mittelstand (28%) and Family (22%) — representing the mass market — require evidence and a trial period before committing. Student and Retired segments maintain hard fee ceilings of CHF 5 that remain non-negotiable regardless of benefit framing. ${yesCount > 0 ? 'At least one segment shows clear adoption potential.' : ''} ${maybeCount >= 2 ? 'The two largest segments (Mittelstand + Family = 50%) are convertible with the right offer.' : ''}`,
    pricing_sweet_spot: 'CHF 8 — balances Mittelstand and Family adoption probability while maintaining meaningful revenue per card',
    top_features:       ['Grocery cashback at Migros and Coop', 'Purchase protection on larger family spending', 'Simple and transparent fee structure', 'Monthly cancellation option'],
    main_barriers:      ['Fee anxiety for budget-constrained segments (Student, Retired)', 'Joint household decision requirement for Family segment', 'Demand for free trial before commitment from Mittelstand'],
    visa_recommendation: `Target the Anna (Mittelstand, 28%) and Sandra (Family, 22%) segments first — together they represent 50% of Swiss adults and both show conversion potential at CHF 8/month with a 30-day free trial. Lead with supermarket cashback at Migros and Coop as the primary acquisition hook. Lukas (Professional, 12%) can be captured with a premium tier at CHF 20–25/month emphasising travel insurance and no foreign fees. Do not prioritise Felix (Student) or Peter (Retired) for initial launch — their fee ceilings make mass acquisition economically marginal.`,
    confidence_level:   confidence,
    verdicts_summary:   { YES: yesCount, MAYBE: maybeCount, NO: noCount },
  };
}

function generateInsightReport(selectedPersonas) {
  const reportTemplates = {
    student: {
      key_metrics: { max_monthly_fee_chf: 'CHF 5', top_feature: 'Zero monthly fee', switching_intent: 'low', twint_loyalty: 'very high', welcome_bonus_effectiveness: 'medium' },
      category_insights: {
        price_sensitivity:  { finding: 'CHF 5 is a firm, principled ceiling — not purely financial but a matter of belief that student banking should be free.', key_quote: "CHF 8 is CHF 96 a year. My debit card is free and Twint is free — why would I pay?", tags: ['fee-free required', 'CHF 5 ceiling', 'principle-based rejection'] },
        feature_preference: { finding: 'Zero fees override all feature considerations — no benefit justifies a fee above CHF 5 for this segment.', key_quote: "Cashback on groceries is the only thing that makes sense for my lifestyle.", tags: ['grocery cashback', 'zero fee', 'mobile-first'] },
        behavior_switching: { finding: 'Switching threshold is extremely low for free products but effectively infinite for any fee-bearing alternative to Twint.', key_quote: "Twint works everywhere and it's free. For me to switch the card would have to be completely free AND offer something Twint doesn't.", tags: ['twint-anchored', 'peer-driven adoption', 'free-only'] },
        trade_off:          { finding: 'Welcome bonuses are viewed with suspicion — Felix calculates the annual net cost and typically finds it unfavourable.', key_quote: "CHF 50 bonus then CHF 72 a year. That's a loss of CHF 22 if I don't use it enough.", tags: ['bonus skepticism', 'annual math', 'cancellation option required'] },
        willingness_to_pay: { finding: 'True maximum is CHF 5/month; anything above is functionally a hard NO regardless of benefit framing.', key_quote: "CHF 5. That's genuinely my absolute maximum.", tags: ['CHF 5 hard ceiling', 'low acquisition priority', 'free-tier required'] },
      },
      visa_recommendation: { viable_product: 'Free Visa Debit with grocery cashback under CHF 5/month', avoid: ['Premium tiers above CHF 5', 'Annual fee structures', 'Travel or luxury benefits'], acquisition_trigger: 'Zero-fee product with small grocery cashback (CHF 2–5/month) and peer social proof' },
    },
    professional: {
      key_metrics: { max_monthly_fee_chf: 'CHF 25–30', top_feature: 'No foreign fees + travel insurance', switching_intent: 'high', twint_loyalty: 'low', welcome_bonus_effectiveness: 'low' },
      category_insights: {
        price_sensitivity:  { finding: 'Fee is evaluated as investment vs return — Lukas calculates total card value against monthly cost at his spending volume.', key_quote: "CHF 8/month is nothing. I spend that on a coffee. What matters is the total value of the card's benefit stack.", tags: ['ROI-driven', 'high spending volume', 'fee-insensitive'] },
        feature_preference: { finding: 'No foreign transaction fees is the primary driver — Lukas travels 4–6 times annually and accumulates significant FX costs.', key_quote: "Travel insurance and no foreign fees — those two together are what I need.", tags: ['travel insurance', 'no foreign fees', 'Apple Pay essential'] },
        behavior_switching: { finding: 'Low switching friction — Lukas will move to a clearly superior product within days if the value case is unambiguous.', key_quote: "If Visa offered a card with better travel coverage and 2% cashback, I would move within a week.", tags: ['fast adopter', 'value-triggered', 'low loyalty'] },
        trade_off:          { finding: 'Welcome bonus is a minor factor — Lukas evaluates ongoing card value, not one-time incentives.', key_quote: "CHF 50 upfront. I'd sign up for the bonus and then keep it if the overall value stack holds up.", tags: ['ongoing value focus', 'bonus indifferent', 'analytical evaluation'] },
        willingness_to_pay: { finding: 'Premium ceiling of CHF 25–30/month for a full-featured travel card; CHF 10–15 without hesitation for mid-range.', key_quote: "CHF 25–30 for a genuinely premium card. For a mid-range card with grocery cashback only, CHF 10–15 is reasonable.", tags: ['CHF 25-30 ceiling', 'premium-receptive', 'high acquisition value'] },
      },
      visa_recommendation: { viable_product: 'Visa Infinite or equivalent premium tier at CHF 20–25/month', avoid: ['Cash-back only cards', 'No Apple Pay', 'Complex redemption systems'], acquisition_trigger: 'Clear travel insurance coverage + competitive cashback rate + seamless Apple Pay integration' },
    },
    mittelstand: {
      key_metrics: { max_monthly_fee_chf: 'CHF 12', top_feature: 'Grocery cashback', switching_intent: 'medium', twint_loyalty: 'high', welcome_bonus_effectiveness: 'medium' },
      category_insights: {
        price_sensitivity:  { finding: 'Anna calculates costs annually — CHF 8/month means CHF 96/year — and expects cashback to demonstrably exceed the fee within 1–2 months.', key_quote: "CHF 8 a month is CHF 96 a year. If I spend CHF 500 on groceries, 1% is CHF 5. That doesn't quite cover the fee.", tags: ['annual-cost thinking', 'evidence-required', 'free-trial essential'] },
        feature_preference: { finding: 'Supermarket cashback on real spending categories (groceries, dining) is the only feature with immediate budget impact for Anna.', key_quote: "Simple, tangible cashback on supermarket spending. Not points — actual money back.", tags: ['grocery-first', 'cash not vouchers', 'Twint integration'] },
        behavior_switching: { finding: 'Moderate switching threshold — Anna will move for demonstrated value but requires peer evidence and a trial period first.', key_quote: "A free trial and clear evidence it saves me money on groceries. Maybe a recommendation from a friend who's used it.", tags: ['peer-evidence required', 'trial-first', 'research-oriented'] },
        trade_off:          { finding: 'Anna performs explicit break-even analysis — CHF 50 bonus vs CHF 72/year — and will switch only when long-term math is positive.', key_quote: "CHF 50 bonus minus CHF 72 annual fee. With 1% cashback on CHF 500/month, I'd come out CHF 38 ahead.", tags: ['break-even analysis', 'long-term evaluation', 'cancellation required'] },
        willingness_to_pay: { finding: 'Comfort zone is CHF 6–8; ceiling is CHF 12 with strong justification and a free trial.', key_quote: "CHF 8 is my comfort zone. I could stretch to CHF 10 for the right product — simple and honest.", tags: ['CHF 8 sweet spot', 'CHF 12 ceiling', 'trial required'] },
      },
      visa_recommendation: { viable_product: 'Visa Standard at CHF 7–9/month with 1% grocery cashback', avoid: ['Points or voucher systems', 'Annual-only pricing', 'Complex redemption'], acquisition_trigger: '30-day free trial + grocery cashback returning more than the fee + verified Swiss user reviews' },
    },
    family: {
      key_metrics: { max_monthly_fee_chf: 'CHF 10', top_feature: 'Family grocery cashback + purchase protection', switching_intent: 'medium', twint_loyalty: 'medium', welcome_bonus_effectiveness: 'high' },
      category_insights: {
        price_sensitivity:  { finding: 'Family grocery spend of CHF 1,000–1,200/month makes 1% cashback highly viable — but joint partner decision is always required.', key_quote: "We spend CHF 1,000–1,200 a month on groceries. 1% back covers the CHF 8 fee. I'd still want to run it by my partner.", tags: ['joint-decision', 'family-budget-lens', 'CHF 10 ceiling'] },
        feature_preference: { finding: 'Purchase protection on large family purchases and supermarket cashback are equally valued — both have direct household relevance.', key_quote: "Purchase protection and cashback on everyday spending. We make a lot of larger purchases for the family.", tags: ['purchase protection', 'grocery cashback', 'family-relevant'] },
        behavior_switching: { finding: 'High switching friction due to partner coordination requirement and multiple direct debits — benefit must clearly outweigh the transition effort.', key_quote: "Both my partner and I would need to agree. There are direct debits linked to our current setup.", tags: ['partner coordination', 'high friction', 'stability preferred'] },
        trade_off:          { finding: 'Welcome bonus is effective for the Family segment — Sandra calculates the long-term value and is willing to try if ongoing cashback is positive.', key_quote: "CHF 50 bonus, ongoing cashback covering the fee. My partner and I would calculate it together.", tags: ['bonus-effective', 'long-term evaluation', 'partner decision'] },
        willingness_to_pay: { finding: 'CHF 5–8 is the comfortable range; CHF 10 maximum with visible family benefit and easy cancellation.', key_quote: "For our family, CHF 8 makes sense if cashback on supermarkets genuinely returns more than the fee.", tags: ['CHF 8 sweet spot', 'CHF 10 ceiling', 'family-relevant required'] },
      },
      visa_recommendation: { viable_product: 'Visa Standard at CHF 7–8/month with family grocery cashback', avoid: ['Solo lifestyle benefits', 'Travel perks without family relevance', 'Complex reward tiers'], acquisition_trigger: 'Supermarket cashback covering the fee + purchase protection + simple cancellation + partner-friendly onboarding' },
    },
    retired: {
      key_metrics: { max_monthly_fee_chf: 'CHF 5', top_feature: 'Security + phone support in German', switching_intent: 'very low', twint_loyalty: 'very low', welcome_bonus_effectiveness: 'very low' },
      category_insights: {
        price_sensitivity:  { finding: 'Fixed pension income makes any new monthly cost directly meaningful — CHF 8/month is CHF 96/year against a CHF 1,682 pension.', key_quote: "CHF 8 a month is CHF 96 a year and my pension is fixed. My PostFinance card is free and does everything.", tags: ['fixed income', 'fee rejection', 'CHF 5 absolute ceiling'] },
        feature_preference: { finding: 'Security and human phone support in German are the only features with real relevance — cashback and travel perks are categorically irrelevant.', key_quote: "Security — that's the first and most important thing. If something goes wrong, I want to call someone who speaks German.", tags: ['security-first', 'phone support required', 'simplicity'] },
        behavior_switching: { finding: 'Switching threshold is effectively prohibitive — 40-year PostFinance relationship constitutes an identity-level loyalty that marketing cannot dislodge.', key_quote: "My routine works. If PostFinance themselves recommended something and explained it clearly, I might listen. Otherwise, no.", tags: ['PostFinance loyalty', 'advisor-trust required', 'near-zero switching probability'] },
        trade_off:          { finding: 'Welcome bonuses are viewed as commercial traps — Peter calculates the long-term cost and rejects any credit product on principle.', key_quote: "CHF 50 welcome bonus doesn't interest me. They give you CHF 50 and charge CHF 120/year. The math isn't generous.", tags: ['bonus suspicion', 'credit rejection', 'long-term cost calculation'] },
        willingness_to_pay: { finding: 'True maximum is CHF 5/month; CHF 0 is preferred. Peter would only accept a fee from a trusted, known institution for a clearly explained benefit.', key_quote: "CHF 0, ideally. CHF 5 is the very maximum I'd even consider, and only for something I understood completely.", tags: ['CHF 5 hard ceiling', 'trust institution required', 'non-priority acquisition'] },
      },
      visa_recommendation: { viable_product: 'Not a priority acquisition target — consider free PostFinance co-branded debit only', avoid: ['Any fee above CHF 5', 'Mobile-first or app-dependent products', 'Credit components', 'Foreign fintech branding'], acquisition_trigger: 'PostFinance or cantonal bank co-branding + CHF 0 cost + human phone support + branch explanation' },
    },
  };

  const result = {};
  selectedPersonas.forEach(p => {
    if (reportTemplates[p]) result[p] = reportTemplates[p];
  });
  return result;
}

module.exports = { PERSONAS, getQuestionsForTopic, getPersonaResponse, generateAnalystInsight, generateInsightReport };
